## Overview

We are **NOT** accepting contributions to this repository,
since we are a very small team with limited resources.

If you are interested in developing your own algorithm based on this library,
please fork it.

## Style

This repository follows Google's internal Python style.

Most importantly, we indent code blocks with *2 spaces*.

Suggested formatting tool: https://www.pylint.org/
